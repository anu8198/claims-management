import java.io.BufferedReader;
import java.io.InputStreamReader;

 class Main {

    public static void main(String[] args) throws Exception {
        
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        
    String date ;
        Long score ;
        String winnerTeam ;
        String playerOfMatch ;
        System.out.println("Enter the number of outcome");
       int n=Integer.parseInt(br.readLine());
        Outcome[] outcome=new Outcome[n];
for(int i=0;i<n;i++)
        {
System.out.println("Enter outcome "+(i+1)+" details");
	System.out.println("Enter the date");
        date=br.readLine();

        System.out.println("Enter the score");
        score=Long.parseLong(br.readLine());
        
        
        System.out.println("Enter the winner team");
        winnerTeam=br.readLine();
        
        
        System.out.println("Enter the player of match");
        playerOfMatch=br.readLine();
        outcome[i]=new Outcome(date,score,winnerTeam,playerOfMatch);
        
        }
OutcomeBO oBo=new OutcomeBO();
System.out.println("1.View details\n2.Search by date\nEnter your choice");
int ch=Integer.parseInt(br.readLine());
switch(ch)
{
case 1:
oBo.displayAllOutcomeDetails(outcome);
break;
case 2:
System.out.println("Enter the date to be searhed");
String sd=br.readLine();
oBo.displaySpecificOutcomeDetails(outcome,sd);
break;
}
    }

}


