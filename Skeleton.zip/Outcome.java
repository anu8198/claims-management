
 class Outcome {
    
    Long score ;
    String winnerTeam ;
    String playerOfMatch ;
    String date;
Outcome(){}
 Outcome(String date,Long score,String winnerTeam,String playerOfMatch)
 {
  this.date=date;
  this.score=score;
  this.winnerTeam=winnerTeam;
  this.playerOfMatch=playerOfMatch;
 }
    public Long getScore() {
        return score;
    }
    public void setScore(Long score) {
        this.score = score;
    }
    public String getWinnerTeam() {
        return winnerTeam;
    }
    public void setWinnerTeam(String winnerTeam) {
        this.winnerTeam = winnerTeam;
    }
    public String getPlayerOfMatch() {
        return playerOfMatch;
    }
    public void setPlayerOfMatch(String playerOfMatch) {
        this.playerOfMatch = playerOfMatch;
    }
    
    
    
    void setDate(String date)
 {
  this.date=date;
 }

 String getDate()
 {
  return date;
 }
    

public String toString()
 {
  return String.format("%-20s %-20s %-20s %s",score,winnerTeam,playerOfMatch,date);
 }
    

}
